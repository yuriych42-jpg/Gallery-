package ru.example.datealbum

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class MediaItem(val uri: Uri, val dateKey: String, val displayName: String, val isVideo: Boolean, val relativePath: String)
private val GalleryBlue = Color(0xFF2878F0)
private val PageBackground = Color(0xFFF5F6F8)

class MainActivity : ComponentActivity() {
    private var pendingMove: List<MediaItem> = emptyList()
    private var pendingAlbumName: String = ""
    private val writePermissionLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == RESULT_OK) movePendingFiles()
        else Toast.makeText(this, "Перемещение отменено", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 246, 248)
        window.navigationBarColor = android.graphics.Color.rgb(245, 246, 248)
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        setContent { GalleryTheme { GalleryScreen() } }
    }

    private fun hasReadPermission(): Boolean = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun queryMedia(): List<MediaItem> {
        val output = mutableListOf<MediaItem>()
        val collections = listOf(MediaStore.Images.Media.EXTERNAL_CONTENT_URI to false, MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true)
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED, MediaStore.Images.ImageColumns.DATE_TAKEN, MediaStore.MediaColumns.RELATIVE_PATH)
        for ((collection, isVideo) in collections) {
            contentResolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val takenCol = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATE_TAKEN)
                val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "media_$id"
                    val taken = if (takenCol >= 0 && !cursor.isNull(takenCol)) cursor.getLong(takenCol) else 0L
                    val timestamp = if (taken > 0L) taken else cursor.getLong(addedCol) * 1000L
                    val dateKey = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(timestamp))
                    val relativePath = if (pathCol >= 0 && !cursor.isNull(pathCol)) cursor.getString(pathCol) ?: "" else ""
                    output += MediaItem(ContentUris.withAppendedId(collection, id), dateKey, name, isVideo, relativePath)
                }
            }
        }
        return output.sortedByDescending { parseDate(it.dateKey) }
    }

    private fun parseDate(value: String): Long = try { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).parse(value)?.time ?: 0L } catch (_: Exception) { 0L }

    @Composable
    private fun GalleryScreen() {
        var permissionGranted by remember { mutableStateOf(hasReadPermission()) }
        var media by remember { mutableStateOf(emptyList<MediaItem>()) }
        var selectedDate by remember { mutableStateOf<String?>(null) }
        var albumName by remember { mutableStateOf("") }
        var searchOpen by remember { mutableStateOf(false) }
        var searchText by remember { mutableStateOf("") }
        var selectedTab by remember { mutableIntStateOf(0) }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionGranted = granted
            if (granted) media = queryMedia()
        }
        LaunchedEffect(permissionGranted) { if (permissionGranted) media = queryMedia() }

        if (!permissionGranted) {
            Box(Modifier.fillMaxSize().background(PageBackground).padding(28.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Collections, null, tint = GalleryBlue, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Ваша галерея", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Разрешите доступ к фото и видео, чтобы увидеть снимки и создавать альбомы по датам.", color = Color.Gray)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE) }) { Text("Разрешить доступ") }
                }
            }
            return
        }

        val filtered = media.filter { it.displayName.contains(searchText, ignoreCase = true) }
        val visibleMedia = when (selectedTab) {
            0 -> filtered.filter { !it.isVideo }
            2 -> filtered.filter { it.isVideo }
            else -> filtered
        }
        val grouped = visibleMedia.groupBy { it.dateKey }.toSortedMap(compareByDescending { parseDate(it) })
        val createdAlbums = filtered.filter { it.relativePath.startsWith("DCIM/DateAlbums/") }
            .groupBy { it.relativePath.removePrefix("DCIM/DateAlbums/").trimEnd('/').substringBefore('/') }
            .filterKeys { it.isNotBlank() }
        Scaffold(
            containerColor = PageBackground,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.ImageIcon, null) }, label = { Text("Фото") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Album, null) }, label = { Text("Альбомы") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Видео") })
                }
            }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Галерея", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF17191D))
                            Text("Ваши воспоминания", color = Color(0xFF7A808A), fontSize = 13.sp)
                        }
                        IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) searchText = "" }) { Icon(Icons.Default.Search, "Поиск", tint = Color(0xFF343941), modifier = Modifier.size(26.dp)) }
                    }
                }
                if (searchOpen) item {
                    OutlinedTextField(value = searchText, onValueChange = { searchText = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(18.dp), placeholder = { Text("Поиск по имени файла") })
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickTile("Фото", "${media.count { !it.isVideo }}", Color(0xFFE7F0FF), GalleryBlue, Icons.Default.ImageIcon, Modifier.weight(1f)) { selectedTab = 0 }
                        QuickTile("Альбомы", "${createdAlbums.size} создано", Color(0xFFF0E9FF), Color(0xFF8956D9), Icons.Default.Folder, Modifier.weight(1f)) { selectedTab = 1 }
                        QuickTile("Видео", "${media.count { it.isVideo }}", Color(0xFFFFE8E8), Color(0xFFE85B61), Icons.Default.VideoLibrary, Modifier.weight(1f)) { selectedTab = 2 }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(when (selectedTab) { 1 -> "Созданные альбомы"; 2 -> "Видео"; else -> "Фото" }, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(when (selectedTab) { 1 -> "${createdAlbums.size} альбомов"; else -> "${visibleMedia.size} файлов" }, fontSize = 12.sp, color = Color.Gray)
                    }
                }
                if (selectedTab == 1) {
                    if (createdAlbums.isEmpty()) item {
                        EmptyGalleryState("Пока нет созданных альбомов", "Создайте альбом из карточки даты в разделе Фото")
                    }
                    createdAlbums.toSortedMap().forEach { (name, albumItems) ->
                        item(key = "album_$name") {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Folder, null, tint = Color(0xFF8956D9), modifier = Modifier.size(28.dp))
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                            Text("${albumItems.size} ${fileWord(albumItems.size)}", fontSize = 12.sp, color = Color.Gray)
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                        albumItems.take(3).forEach { mediaItem -> MediaThumbnail(mediaItem, Modifier.weight(1f).height(104.dp)) }
                                        repeat((3 - albumItems.size.coerceAtMost(3)).coerceAtLeast(0)) { Box(Modifier.weight(1f).height(104.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF0F1F4))) }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (visibleMedia.isEmpty()) item {
                        EmptyGalleryState(if (searchText.isNotBlank()) "Ничего не найдено" else if (selectedTab == 2) "Видео не найдены" else "Фото не найдены", "Файлы выбранного типа появятся здесь автоматически")
                    }
                    grouped.forEach { (date, dateItems) ->
                        item(key = "date_$date") {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 2.dp, bottom = 12.dp)) {
                                        Column(Modifier.weight(1f)) {
                                            Text(dateLabel(date), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF202329))
                                            Text("$date · ${dateItems.size} ${fileWord(dateItems.size)}", fontSize = 12.sp, color = Color(0xFF828792))
                                        }
                                        if (selectedTab == 0) FilledTonalButton(onClick = { selectedDate = date; albumName = date }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFE8F1FF), contentColor = GalleryBlue), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                                            Icon(Icons.Default.Album, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(5.dp))
                                            Text("В альбом", fontSize = 12.sp)
                                        }
                                    }
                                    val previews = dateItems.take(3)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                        previews.forEach { mediaItem -> MediaThumbnail(mediaItem, Modifier.weight(1f).height(104.dp)) }
                                        repeat(3 - previews.size) { Box(Modifier.weight(1f).height(104.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF0F1F4))) }
                                    }
                                    if (dateItems.size > 3) Text("Ещё ${dateItems.size - 3} файлов", color = Color(0xFF858B95), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, start = 2.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        selectedDate?.let { date ->
            AlertDialog(
                onDismissRequest = { selectedDate = null },
                shape = RoundedCornerShape(28.dp),
                title = { Text("Создать альбом", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Все фото и видео за $date будут перемещены в отдельную папку.", color = Color(0xFF666C76))
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(value = albumName, onValueChange = { albumName = it }, label = { Text("Название альбома") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("Папка: DCIM/DateAlbums/…", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val safeName = albumName.trim().replace("/", "_").replace("\\", "_")
                        if (safeName.isBlank()) Toast.makeText(this, "Введите название альбома", Toast.LENGTH_SHORT).show()
                        else { pendingMove = media.filter { it.dateKey == date }; pendingAlbumName = safeName; selectedDate = null; requestMovePermission() }
                    }) { Text("Создать и переместить") }
                },
                dismissButton = { TextButton(onClick = { selectedDate = null }) { Text("Отмена") } }
            )
        }
    }

    private fun requestMovePermission() {
        if (pendingMove.isEmpty()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val request = MediaStore.createWriteRequest(contentResolver, pendingMove.map { it.uri })
                writePermissionLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            } catch (e: Exception) { Toast.makeText(this, "Не удалось запросить разрешение: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
        } else movePendingFiles()
    }

    private fun movePendingFiles() {
        val targetPath = "DCIM/DateAlbums/${pendingAlbumName.trimEnd('/')}/"
        var moved = 0; var failed = 0
        pendingMove.forEach { item ->
            try {
                val values = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath) }
                if (contentResolver.update(item.uri, values, null, null) > 0) moved++ else failed++
            } catch (_: Exception) { failed++ }
        }
        Toast.makeText(this, "Перемещено: $moved. Ошибок: $failed", Toast.LENGTH_LONG).show()
        pendingMove = emptyList()
        setContent { GalleryTheme { GalleryScreen() } }
    }
}

@Composable
private fun EmptyGalleryState(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Collections, null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.Gray, fontSize = 13.sp)
        }
    }
}

@Composable
private fun GalleryTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = GalleryBlue, secondary = Color(0xFF8956D9), background = PageBackground, surface = Color.White), content = content)
}

@Composable
private fun QuickTile(title: String, subtitle: String, bg: Color, fg: Color, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(bg), contentAlignment = Alignment.Center) { Icon(icon, null, tint = fg, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.height(7.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(subtitle, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
        }
    }
}

@Composable
private fun MediaThumbnail(item: MediaItem, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = item.uri) {
        value = withContext(Dispatchers.IO) {
            try { context.contentResolver.loadThumbnail(item.uri, Size(360, 360), null) } catch (_: Exception) { null }
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFE6E9EE))
            .clickable {
                try {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(item.uri, if (item.isVideo) "video/*" else "image/*")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {
                    android.widget.Toast.makeText(context, "Не удалось открыть файл", android.widget.Toast.LENGTH_SHORT).show()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = item.displayName, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(if (item.isVideo) Icons.Default.VideoLibrary else Icons.Default.ImageIcon, null, tint = Color(0xFF9AA2AE), modifier = Modifier.size(28.dp))
        if (item.isVideo) Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(24.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
            Text("▶", color = Color.White, fontSize = 10.sp)
        }
    }
}

private fun dateLabel(value: String): String {
    val today = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
    val yesterday = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000))
    return when (value) { today -> "Сегодня"; yesterday -> "Вчера"; else -> value }
}

private fun fileWord(count: Int): String = when {
    count % 10 == 1 && count % 100 != 11 -> "файл"
    count % 10 in 2..4 && count % 100 !in 12..14 -> "файла"
    else -> "файлов"
}
