package ru.example.datealbum

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class MediaItem(val uri: Uri, val dateKey: String, val displayName: String, val isVideo: Boolean, val relativePath: String)
private val GalleryBlue = Color(0xFF2878F0)
private val PageBackground = Color(0xFFF5F6F8)

private object ThumbnailCache {
    private val cache = object : android.util.LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    fun get(uri: Uri): Bitmap? = cache.get(uri.toString())
    fun put(uri: Uri, bitmap: Bitmap) { cache.put(uri.toString(), bitmap) }
}

class MainActivity : ComponentActivity() {
    private var pendingMove: List<MediaItem> = emptyList()
    private var pendingAlbumName: String = ""
    private val writePermissionLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == RESULT_OK) movePendingFiles()
        else Toast.makeText(this@MainActivity, "Перемещение отменено", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 246, 248)
        window.navigationBarColor = android.graphics.Color.rgb(245, 246, 248)
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        setContent { GalleryTheme { GalleryScreen() } }
    }

    private fun requiredMediaPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun hasReadPermission(): Boolean = requiredMediaPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun queryMedia(): List<MediaItem> {
        val output = mutableListOf<MediaItem>()
        val collections = listOf(MediaStore.Images.Media.EXTERNAL_CONTENT_URI to false, MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true)
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED, MediaStore.Images.ImageColumns.DATE_TAKEN, MediaStore.MediaColumns.RELATIVE_PATH)
        for ((collection, isVideo) in collections) {
            contentResolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val takenCol = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATE_TAKEN)
                val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "media_$id"
                    val taken = if (takenCol >= 0 && !cursor.isNull(takenCol)) cursor.getLong(takenCol) else 0L
                    val timestamp = if (taken > 0L) taken else cursor.getLong(addedCol) * 1000L
                    val dateKey = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(timestamp))
                    val relativePath = if (pathCol >= 0 && !cursor.isNull(pathCol)) cursor.getString(pathCol).orEmpty() else ""
                    output += MediaItem(ContentUris.withAppendedId(collection, id), dateKey, name, isVideo, relativePath)
                }
            }
        }
        return output.sortedByDescending { parseDate(it.dateKey) }
    }


    private fun loadDisplayBitmap(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val maxSide = 2400
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1); inPreferredConfig = Bitmap.Config.ARGB_8888 }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        } catch (_: Exception) { null }
    }

    private fun saveRotatedCopy(item: MediaItem, degrees: Float): Boolean {
        if (degrees % 360f == 0f) return true
        return try {
            val original = loadDisplayBitmap(item.uri) ?: return false
            val matrix = Matrix().apply { postRotate(degrees) }
            val rotated = Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "${item.displayName.substringBeforeLast('.', item.displayName)}_rotated_${System.currentTimeMillis()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/DateAlbums/Rotated")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val target = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            val wrote = contentResolver.openOutputStream(target)?.use { stream -> rotated.compress(Bitmap.CompressFormat.JPEG, 96, stream) } ?: false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                contentResolver.update(target, done, null, null)
            }
            if (rotated !== original && !rotated.isRecycled) rotated.recycle()
            wrote
        } catch (_: Exception) { false }
    }

    private fun saveCroppedCopy(item: MediaItem, cropped: Bitmap): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "${item.displayName.substringBeforeLast('.', item.displayName)}_cropped_${System.currentTimeMillis()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/DateAlbums/Cropped")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val target = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            val wrote = contentResolver.openOutputStream(target)?.use { stream -> cropped.compress(Bitmap.CompressFormat.JPEG, 96, stream) } ?: false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                contentResolver.update(target, done, null, null)
            }
            wrote
        } catch (_: Exception) { false }
    }

    private fun parseDate(value: String): Long = try { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).parse(value)?.time ?: 0L } catch (_: Exception) { 0L }

    @OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
    @Composable
    private fun GalleryScreen() {
        var permissionGranted by remember { mutableStateOf(hasReadPermission()) }
        var media by remember { mutableStateOf(emptyList<MediaItem>()) }
        var selectedDate by remember { mutableStateOf<String?>(null) }
        var albumName by remember { mutableStateOf("") }
        var searchOpen by remember { mutableStateOf(false) }
        var searchText by remember { mutableStateOf("") }
        var selectedTab by remember { mutableIntStateOf(0) }
        var selectedMedia by remember { mutableStateOf<MediaItem?>(null) }
        var gridMode by remember { mutableStateOf(true) }
        var selectedUris by remember { mutableStateOf(setOf<String>()) }
        var selectedAlbumPaths by remember { mutableStateOf(setOf<String>()) }
        var confirmDelete by remember { mutableStateOf(false) }
        var pendingRotationItem by remember { mutableStateOf<MediaItem?>(null) }
        var pendingRotationDegrees by remember { mutableFloatStateOf(0f) }
        var croppingItem by remember { mutableStateOf<MediaItem?>(null) }
        var cropSourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
        var cropLoading by remember { mutableStateOf(false) }
        val croppedPreviewBitmaps = remember { mutableStateMapOf<String, Bitmap>() }
        val rotations = remember { mutableStateMapOf<String, Float>() }
        val scope = rememberCoroutineScope()
        val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == RESULT_OK) { scope.launch { media = withContext(Dispatchers.IO) { queryMedia() } }; selectedUris = emptySet(); selectedAlbumPaths = emptySet(); selectedMedia = null; Toast.makeText(this@MainActivity, "Удаление выполнено", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(this@MainActivity, "Удаление отменено", Toast.LENGTH_SHORT).show()
        }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            permissionGranted = results.values.all { it }
            if (permissionGranted) scope.launch { media = withContext(Dispatchers.IO) { queryMedia() } }
        }
        LaunchedEffect(permissionGranted) {
            if (permissionGranted) media = withContext(Dispatchers.IO) { queryMedia() }
        }

        if (!permissionGranted) {
            Box(Modifier.fillMaxSize().background(PageBackground).padding(28.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Collections, null, tint = GalleryBlue, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Ваша галерея", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Разрешите доступ к фото и видео, чтобы увидеть снимки и создавать альбомы по датам.", color = Color.Gray)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { permissionLauncher.launch(requiredMediaPermissions()) }) { Text("Разрешить доступ") }
                }
            }
            return
        }

        val filtered = media.filter { item ->
            item.displayName.contains(searchText, ignoreCase = true) &&
                when (selectedTab) {
                    0 -> !item.isVideo
                    2 -> item.isVideo
                    3 -> true
                    4 -> !item.relativePath.startsWith("DCIM/DateAlbums/", ignoreCase = true) && !item.relativePath.startsWith("Pictures/DateAlbums/", ignoreCase = true)
                    else -> true
                }
        }
        val grouped = filtered.groupBy { it.dateKey }.toSortedMap(compareByDescending { parseDate(it) })
        Scaffold(
            containerColor = PageBackground,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.ImageIcon, null) }, label = { Text("Фото") })
                    NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 }, icon = { Icon(Icons.Default.Collections, null) }, label = { Text("Все") })
                    NavigationBarItem(selected = selectedTab == 1 || selectedTab == 4, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Album, null) }, label = { Text("Альбомы") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Видео") })
                }
            }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Галерея", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF17191D))
                            Text("Ваши воспоминания", color = Color(0xFF7A808A), fontSize = 13.sp)
                            Text("Версия 0.30", color = Color(0xFF969BA4), fontSize = 11.sp)
                        }
                        IconButton(onClick = { gridMode = !gridMode }) { Icon(if (gridMode) Icons.Default.ViewList else Icons.Default.GridView, if (gridMode) "Список" else "Плитки", tint = Color(0xFF343941), modifier = Modifier.size(24.dp)) }
                        IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) searchText = "" }) { Icon(Icons.Default.Search, "Поиск", tint = Color(0xFF343941), modifier = Modifier.size(26.dp)) }
                    }
                }
                if (searchOpen) item {
                    OutlinedTextField(value = searchText, onValueChange = { searchText = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(18.dp), placeholder = { Text("Поиск по имени файла") })
                }
                if (selectedUris.isNotEmpty() || selectedAlbumPaths.isNotEmpty()) item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE7F0FF)), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Выбрано: ${selectedUris.size + selectedAlbumPaths.size}", modifier = Modifier.weight(1f), color = GalleryBlue, fontWeight = FontWeight.SemiBold)
                            TextButton(onClick = { selectedUris = emptySet(); selectedAlbumPaths = emptySet() }) { Text("Снять") }
                            Button(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(5.dp)); Text("Удалить") }
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickTile("Фото", "${media.count { !it.isVideo }}", Color(0xFFE7F0FF), GalleryBlue, Icons.Default.ImageIcon, Modifier.weight(1f)) { selectedTab = 0 }
                        QuickTile("Все", "${media.size}", Color(0xFFE8F7EF), Color(0xFF218653), Icons.Default.Collections, Modifier.weight(1f)) { selectedTab = 3 }
                        QuickTile("Альбомы", "По папкам", Color(0xFFF0E9FF), Color(0xFF8956D9), Icons.Default.Folder, Modifier.weight(1f)) { selectedTab = 1 }
                        QuickTile("Видео", "${media.count { it.isVideo }}", Color(0xFFFFE8E8), Color(0xFFE85B61), Icons.Default.VideoLibrary, Modifier.weight(1f)) { selectedTab = 2 }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(when (selectedTab) { 1 -> "Альбомы телефона"; 2 -> "Видео"; 3 -> "Все фото и видео"; 4 -> "Без альбома приложения"; else -> "Все фото" }, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${filtered.size} файлов", fontSize = 12.sp, color = Color.Gray)
                    }
                }
                if (filtered.isEmpty()) item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Collections, null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(if (media.isEmpty()) "Медиафайлы не найдены" else "Ничего не найдено", fontWeight = FontWeight.SemiBold)
                            Text("Фото и видео появятся здесь автоматически", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
                if (selectedTab == 1) {
                    val albums = filtered.groupBy { it.relativePath.trimEnd('/').ifBlank { "Без папки" } }
                        .toList().sortedBy { it.first.lowercase(Locale.getDefault()) }
                    val unassignedItems = media.filter { !it.relativePath.startsWith("DCIM/DateAlbums/", ignoreCase = true) && !it.relativePath.startsWith("Pictures/DateAlbums/", ignoreCase = true) }
                    item(key = "album:unassigned") {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                            Row(Modifier.fillMaxWidth().clickable { selectedTab = 4 }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box { if (unassignedItems.isNotEmpty()) MediaThumbnail(unassignedItems.first(), Modifier.size(88.dp)) { selectedTab = 4 } else Icon(Icons.Default.Collections, null, modifier = Modifier.size(88.dp).padding(22.dp), tint = Color.LightGray) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Без альбома приложения", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("Фото и видео из остальных папок телефона", fontSize = 12.sp, color = Color.Gray)
                                    Text("${unassignedItems.size} файлов", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                    if (albums.isEmpty()) item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Folder, null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("Альбомы пока не найдены", fontWeight = FontWeight.SemiBold)
                                Text("Папки с фото и видео появятся здесь", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    }
                    albums.forEach { (folder, albumItems) ->
                        item(key = "album:$folder") {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                                Row(Modifier.fillMaxWidth().combinedClickable(onClick = {
                                    if (selectedUris.isNotEmpty() || selectedAlbumPaths.isNotEmpty()) { selectedAlbumPaths = if (folder in selectedAlbumPaths) selectedAlbumPaths - folder else selectedAlbumPaths + folder }
                                    else selectedMedia = albumItems.first()
                                }, onLongClick = { selectedAlbumPaths = selectedAlbumPaths + folder }).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box { MediaThumbnail(albumItems.first(), Modifier.size(88.dp)) { if (selectedAlbumPaths.isNotEmpty()) selectedAlbumPaths = if (folder in selectedAlbumPaths) selectedAlbumPaths - folder else selectedAlbumPaths + folder else selectedMedia = albumItems.first() }; if (folder in selectedAlbumPaths) Icon(Icons.Default.CheckCircle, null, tint = GalleryBlue, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(folder.substringAfterLast('/'), fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                                        Text("${albumItems.size} ${fileWord(albumItems.size)}", fontSize = 12.sp, color = Color.Gray)
                                        Text(folder, fontSize = 11.sp, color = Color.Gray, maxLines = 2)
                                    }
                                }
                            }
                        }
                    }
                } else grouped.forEach { (date, dateItems) ->
                    item(key = date) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 2.dp, bottom = 12.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(dateLabel(date), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF202329))
                                        Text("$date · ${dateItems.size} ${fileWord(dateItems.size)}", fontSize = 12.sp, color = Color(0xFF828792))
                                    }
                                    FilledTonalButton(onClick = { selectedDate = date; albumName = date }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFE8F1FF), contentColor = GalleryBlue), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                                        Icon(Icons.Default.Album, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text("В альбом", fontSize = 12.sp)
                                    }
                                }
                                if (gridMode) {
                                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                                    val tileWidth = (maxWidth - 12.dp) / 3
                                    FlowRow(modifier = Modifier.fillMaxWidth(), maxItemsInEachRow = 3, horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        dateItems.forEach { mediaItem ->
                                            val isSelected = mediaItem.uri.toString() in selectedUris
                                            Box(Modifier.width(tileWidth).aspectRatio(1f).clip(RoundedCornerShape(10.dp))) {
                                                MediaThumbnail(mediaItem, Modifier.fillMaxSize()) {
                                                    if (selectedUris.isNotEmpty() || selectedAlbumPaths.isNotEmpty()) selectedUris = if (isSelected) selectedUris - mediaItem.uri.toString() else selectedUris + mediaItem.uri.toString()
                                                    else selectedMedia = mediaItem
                                                }
                                                Box(Modifier.fillMaxSize().combinedClickable(onClick = { if (selectedUris.isNotEmpty() || selectedAlbumPaths.isNotEmpty()) selectedUris = if (isSelected) selectedUris - mediaItem.uri.toString() else selectedUris + mediaItem.uri.toString() else selectedMedia = mediaItem }, onLongClick = { selectedUris = selectedUris + mediaItem.uri.toString() }))
                                                if (isSelected) Icon(Icons.Default.CheckCircle, null, tint = GalleryBlue, modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(24.dp))
                                                if (mediaItem.isVideo) Text("▶", color = Color.White, modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).background(Color.Black.copy(alpha = .55f), CircleShape).padding(horizontal = 7.dp, vertical = 3.dp))
                                            }
                                        }
                                    }
                                    }
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        dateItems.forEach { mediaItem ->
                                            val isSelected = mediaItem.uri.toString() in selectedUris
                                            Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).combinedClickable(onClick = {
                                                if (selectedUris.isNotEmpty() || selectedAlbumPaths.isNotEmpty()) selectedUris = if (isSelected) selectedUris - mediaItem.uri.toString() else selectedUris + mediaItem.uri.toString() else selectedMedia = mediaItem
                                            }, onLongClick = { selectedUris = selectedUris + mediaItem.uri.toString() }).background(if (isSelected) Color(0xFFDCEAFF) else Color.Transparent).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Box { MediaThumbnail(mediaItem, Modifier.size(width = 104.dp, height = 92.dp)) { selectedMedia = mediaItem }; if (isSelected) Icon(Icons.Default.CheckCircle, null, tint = GalleryBlue, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) }
                                                Spacer(Modifier.width(12.dp))
                                                Column(Modifier.weight(1f)) { Text(mediaItem.displayName, maxLines = 2, fontSize = 14.sp, fontWeight = FontWeight.Medium); Text(if (mediaItem.isVideo) "Видео" else "Фото", fontSize = 12.sp, color = Color.Gray) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        val closeViewer: () -> Unit = {
            selectedMedia = null
            val changed = rotations.entries.firstOrNull { kotlin.math.abs(it.value) >= 45f }
            if (changed != null) {
                pendingRotationItem = media.firstOrNull { it.uri.toString() == changed.key }
                pendingRotationDegrees = changed.value
            }
        }

        selectedMedia?.let { item ->
            val viewerItems = remember(item, media, selectedTab) {
                val source = when (selectedTab) { 0 -> media.filter { !it.isVideo }; 2 -> media.filter { it.isVideo }; else -> media }
                (source.ifEmpty { media }).sortedByDescending { parseDate(it.dateKey) }
            }
            val initialPage = (viewerItems.indexOfFirst { it.uri == item.uri }).coerceAtLeast(0)
            val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { viewerItems.size })
            Dialog(onDismissRequest = { closeViewer() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), key = { page -> viewerItems[page].uri.toString() }) { page ->
                        val pageItem = viewerItems[page]
                        if (pageItem.isVideo) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.VideoLibrary, null, tint = Color.White, modifier = Modifier.size(56.dp))
                                    Spacer(Modifier.height(12.dp)); Text("Нажмите, чтобы открыть видео", color = Color.White)
                                    Spacer(Modifier.height(8.dp))
                                    Button(onClick = {
                                        try { startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(pageItem.uri, "video/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
                                        catch (_: Exception) { Toast.makeText(this@MainActivity, "Не удалось открыть видео", Toast.LENGTH_SHORT).show() }
                                    }) { Text("▶ Открыть видео") }
                                }
                            }
                        } else {
                            var bitmap by remember(pageItem.uri) { mutableStateOf<Bitmap?>(croppedPreviewBitmaps[pageItem.uri.toString()] ?: ThumbnailCache.get(pageItem.uri)) }
                            var scale by remember(pageItem.uri) { mutableFloatStateOf(1f) }
                            var offsetX by remember(pageItem.uri) { mutableFloatStateOf(0f) }
                            var offsetY by remember(pageItem.uri) { mutableFloatStateOf(0f) }
                            val rotation = rotations[pageItem.uri.toString()] ?: 0f
                            LaunchedEffect(pageItem.uri) {
                                // Keep the just-cropped result visible instead of replacing it with the original image.
                                val croppedPreview = croppedPreviewBitmaps[pageItem.uri.toString()]
                                if (croppedPreview != null) {
                                    bitmap = croppedPreview
                                } else {
                                // Show a small MediaStore thumbnail immediately, then decode the full-resolution image in the background.
                                if (bitmap == null) {
                                    val preview = withContext(Dispatchers.IO) {
                                        try { contentResolver.loadThumbnail(pageItem.uri, Size(480, 640), null) } catch (_: Exception) { null }
                                    }
                                    if (preview != null) { bitmap = preview; ThumbnailCache.put(pageItem.uri, preview) }
                                }
                                val sharper = withContext(Dispatchers.IO) { loadDisplayBitmap(pageItem.uri) }
                                if (sharper != null) { ThumbnailCache.put(pageItem.uri, sharper); bitmap = sharper }
                                }
                            }
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                val visibleBitmap = croppedPreviewBitmaps[pageItem.uri.toString()] ?: bitmap
                                if (visibleBitmap != null) Image(
                                    bitmap = visibleBitmap.asImageBitmap(), contentDescription = pageItem.displayName,
                                    modifier = Modifier.fillMaxSize().graphicsLayer {
                                        scaleX = scale
                                        scaleY = scale
                                        rotationZ = rotation
                                        translationX = offsetX
                                        translationY = offsetY
                                    }
                                        .pointerInput(pageItem.uri) {
                                            awaitEachGesture {
                                                awaitFirstDown(requireUnconsumed = false)
                                                var previousCentroidX = 0f
                                                var previousCentroidY = 0f
                                                var previousSpan = 0f
                                                var previousAngle = 0f
                                                var rotationAccum = 0f
                                                do {
                                                    val event = awaitPointerEvent(PointerEventPass.Main)
                                                    val pressed = event.changes.filter { it.pressed }
                                                    if (pressed.size >= 2) {
                                                        val p1 = pressed[0].position
                                                        val p2 = pressed[1].position
                                                        val cx = (p1.x + p2.x) / 2f
                                                        val cy = (p1.y + p2.y) / 2f
                                                        val dx = p2.x - p1.x
                                                        val dy = p2.y - p1.y
                                                        val span = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                                                        val angle = Math.toDegrees(kotlin.math.atan2(dy, dx).toDouble()).toFloat()
                                                        if (previousSpan > 0f) {
                                                            val zoom = span / previousSpan
                                                            scale = (scale * zoom).coerceIn(1f, 5f)
                                                            offsetX += cx - previousCentroidX
                                                            offsetY += cy - previousCentroidY
                                                            var deltaAngle = angle - previousAngle
                                                            if (deltaAngle > 180f) deltaAngle -= 360f
                                                            if (deltaAngle < -180f) deltaAngle += 360f
                                                            // Accumulate rotation during the gesture and snap once on finger release.
                                                            // Updating rotation every few degrees causes visible jumps while pinching.
                                                            rotationAccum += deltaAngle
                                                            val maxX = (size.width * (scale - 1f) * 0.85f).coerceAtLeast(0f)
                                                            val maxY = (size.height * (scale - 1f) * 0.85f).coerceAtLeast(0f)
                                                            offsetX = if (scale > 1f) offsetX.coerceIn(-maxX, maxX) else 0f
                                                            offsetY = if (scale > 1f) offsetY.coerceIn(-maxY, maxY) else 0f
                                                            pressed.forEach { it.consume() }
                                                        }
                                                        previousSpan = span
                                                        previousCentroidX = cx
                                                        previousCentroidY = cy
                                                        previousAngle = angle
                                                    } else if (pressed.size == 1 && scale > 1f) {
                                                        val delta = event.changes.first().positionChange()
                                                        offsetX += delta.x
                                                        offsetY += delta.y
                                                        val maxX = (size.width * (scale - 1f) * 0.85f).coerceAtLeast(0f)
                                                        val maxY = (size.height * (scale - 1f) * 0.85f).coerceAtLeast(0f)
                                                        offsetX = offsetX.coerceIn(-maxX, maxX)
                                                        offsetY = offsetY.coerceIn(-maxY, maxY)
                                                        event.changes.forEach { it.consume() }
                                                    } else {
                                                        previousSpan = 0f
                                                    }
                                                } while (event.changes.any { it.pressed })
                                                if (kotlin.math.abs(rotationAccum) >= 45f) {
                                                    val steps = kotlin.math.round(rotationAccum / 90f).toInt().coerceIn(-4, 4)
                                                    if (steps != 0) {
                                                        val key = pageItem.uri.toString()
                                                        rotations[key] = (((rotations[key] ?: 0f) + steps * 90f) % 360f)
                                                    }
                                                }
                                            }
                                        }
                                        .pointerInput(pageItem.uri) {
                                            detectTapGestures(onDoubleTap = {
                                                scale = when {
                                                    scale < 1.5f -> 2.5f
                                                    scale < 3.2f -> 4.5f
                                                    else -> 1f
                                                }
                                                if (scale == 1f) { offsetX = 0f; offsetY = 0f }
                                            })
                                        }, contentScale = ContentScale.Fit
                                ) else CircularProgressIndicator(color = Color.White)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().align(Alignment.TopCenter).background(Color.Black.copy(alpha = 0.58f))
                        .padding(start = 8.dp, end = 16.dp, top = 36.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { closeViewer() }) { Text("‹", color = Color.White, fontSize = 34.sp) }
                        Text(viewerItems.getOrNull(pagerState.currentPage)?.displayName ?: item.displayName,
                            color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
                    }
                    val currentItem = viewerItems.getOrNull(pagerState.currentPage)
                    Row(
                        Modifier.fillMaxWidth().align(Alignment.BottomCenter).background(Color.Black.copy(alpha = 0.72f))
                            .navigationBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (currentItem != null && !currentItem.isVideo) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(onClick = {
                                    val key = currentItem.uri.toString()
                                    rotations[key] = (((rotations[key] ?: 0f) + 90f) % 360f)
                                }) { Icon(Icons.Default.RotateRight, "Повернуть по часовой", tint = Color.White) }
                                Text("По часовой", color = Color.White, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(onClick = {
                                    val key = currentItem.uri.toString()
                                    rotations[key] = (((rotations[key] ?: 0f) - 90f) % 360f)
                                }) { Icon(Icons.Default.RotateLeft, "Повернуть против часовой", tint = Color.White) }
                                Text("Против часовой", color = Color.White, fontSize = 10.sp)
                            }
                        }
                        if (currentItem != null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(onClick = { selectedUris = setOf(currentItem.uri.toString()); confirmDelete = true }) {
                                    Icon(Icons.Default.Delete, "Удалить фото", tint = Color.White)
                                }
                                Text("Удалить", color = Color.White, fontSize = 10.sp)
                            }
                        }
                        if (currentItem != null && !currentItem.isVideo) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(onClick = {
                                    croppingItem = currentItem
                                    cropSourceBitmap = null
                                    cropLoading = true
                                    scope.launch {
                                        cropSourceBitmap = withContext(Dispatchers.IO) { loadDisplayBitmap(currentItem.uri) }
                                        cropLoading = false
                                        if (cropSourceBitmap == null) {
                                            croppingItem = null
                                            Toast.makeText(this@MainActivity, "Не удалось загрузить фото для обрезки", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }) { Icon(Icons.Default.Crop, "Обрезать фото", tint = Color.White) }
                                Text("Обрезать", color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        if (croppingItem != null) {
            val itemToCrop = croppingItem!!
            if (cropLoading) {
                Dialog(onDismissRequest = { croppingItem = null; cropSourceBitmap = null }) {
                    Surface(shape = RoundedCornerShape(20.dp), color = Color.White) {
                        Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator()
                            Spacer(Modifier.width(16.dp))
                            Text("Подготовка фото к обрезке…")
                        }
                    }
                }
            } else if (cropSourceBitmap != null) {
                InAppCropDialog(
                    source = cropSourceBitmap!!,
                    onCancel = { croppingItem = null; cropSourceBitmap = null },
                    onSave = { cropped ->
                        croppingItem = null
                        cropSourceBitmap = null
                        scope.launch {
                            val success = withContext(Dispatchers.IO) { saveCroppedCopy(itemToCrop, cropped) }
                            if (success) {
                                // Keep the crop in the viewer for this original item; do not replace it with the original on reload.
                                croppedPreviewBitmaps[itemToCrop.uri.toString()] = cropped
                                media = withContext(Dispatchers.IO) { queryMedia() }
                            } else if (!cropped.isRecycled) {
                                cropped.recycle()
                            }
                            Toast.makeText(this@MainActivity, if (success) "Обрезанная копия сохранена. На экране показан результат" else "Не удалось сохранить обрезанное фото", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
        }

        if (pendingRotationItem != null) {
            val rotatedItem = pendingRotationItem!!
            AlertDialog(
                onDismissRequest = { rotations[rotatedItem.uri.toString()] = 0f; pendingRotationItem = null },
                title = { Text("Сохранить поворот?") },
                text = { Text("Фото повёрнуто на ${pendingRotationDegrees.toInt()}°. Сохранить повёрнутую копию? Оригинал останется без изменений.") },
                confirmButton = {
                    Button(onClick = {
                        pendingRotationItem = null
                        scope.launch {
                            val success = withContext(Dispatchers.IO) { saveRotatedCopy(rotatedItem, pendingRotationDegrees) }
                            if (success) media = withContext(Dispatchers.IO) { queryMedia() }
                            Toast.makeText(this@MainActivity, if (success) "Копия сохранена в Pictures/DateAlbums/Rotated" else "Не удалось сохранить фото", Toast.LENGTH_LONG).show()
                            if (success) rotations[rotatedItem.uri.toString()] = 0f
                        }
                    }) { Text("Сохранить копию") }
                },
                dismissButton = { TextButton(onClick = { rotations[rotatedItem.uri.toString()] = 0f; pendingRotationItem = null }) { Text("Не сохранять") } }
            )
        }

        if (confirmDelete) {
            val deleteItems = media.filter { it.uri.toString() in selectedUris || it.relativePath.trimEnd('/').ifBlank { "Без папки" } in selectedAlbumPaths }
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Удалить выбранное?") },
                text = { Text("Будет удалено файлов: ${deleteItems.size}. Удаление может быть необратимым.") },
                confirmButton = { Button(onClick = {
                    confirmDelete = false
                    if (deleteItems.isEmpty()) { selectedUris = emptySet(); selectedAlbumPaths = emptySet() }
                    else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        try { val request = MediaStore.createDeleteRequest(contentResolver, deleteItems.map { it.uri }); deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build()) }
                        catch (_: Exception) { Toast.makeText(this@MainActivity, "Не удалось запросить удаление", Toast.LENGTH_LONG).show() }
                    } else {
                        scope.launch { val deleted = withContext(Dispatchers.IO) { var count = 0; deleteItems.forEach { try { if (contentResolver.delete(it.uri, null, null) > 0) count++ } catch (_: Exception) {} }; count }; media = withContext(Dispatchers.IO) { queryMedia() }; selectedUris = emptySet(); selectedAlbumPaths = emptySet(); selectedMedia = null; Toast.makeText(this@MainActivity, "Удалено: $deleted", Toast.LENGTH_SHORT).show() }
                    }
                }) { Text("Удалить") } },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } }
            )
        }

        selectedDate?.let { date ->
            AlertDialog(
                onDismissRequest = { selectedDate = null },
                shape = RoundedCornerShape(28.dp),
                title = { Text("Создать альбом", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Все фото и видео за $date будут перемещены в отдельную папку.", color = Color(0xFF666C76))
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(value = albumName, onValueChange = { albumName = it }, label = { Text("Название альбома") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("Папка: DCIM/DateAlbums/…", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val safeName = albumName.trim().replace("/", "_").replace("\\", "_")
                        if (safeName.isBlank()) Toast.makeText(this@MainActivity, "Введите название альбома", Toast.LENGTH_SHORT).show()
                        else { pendingMove = media.filter { it.dateKey == date }; pendingAlbumName = safeName; selectedDate = null; requestMovePermission() }
                    }) { Text("Создать и переместить") }
                },
                dismissButton = { TextButton(onClick = { selectedDate = null }) { Text("Отмена") } }
            )
        }
    }

    private fun requestMovePermission() {
        if (pendingMove.isEmpty()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val request = MediaStore.createWriteRequest(contentResolver, pendingMove.map { it.uri })
                writePermissionLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Не удалось запросить разрешение: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
        } else movePendingFiles()
    }

    private fun movePendingFiles() {
        val targetPath = "DCIM/DateAlbums/${pendingAlbumName.trimEnd('/')}/"
        var moved = 0; var failed = 0
        pendingMove.forEach { item ->
            try {
                val values = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath) }
                if (contentResolver.update(item.uri, values, null, null) > 0) moved++ else failed++
            } catch (_: Exception) { failed++ }
        }
        Toast.makeText(this@MainActivity, "Перемещено: $moved. Ошибок: $failed", Toast.LENGTH_LONG).show()
        pendingMove = emptyList()
        setContent { GalleryTheme { GalleryScreen() } }
    }
}

@Composable
private fun InAppCropDialog(source: Bitmap, onCancel: () -> Unit, onSave: (Bitmap) -> Unit) {
    var left by remember(source) { mutableFloatStateOf(0.1f) }
    var top by remember(source) { mutableFloatStateOf(0.1f) }
    var cropW by remember(source) { mutableFloatStateOf(0.8f) }
    var cropH by remember(source) { mutableFloatStateOf(0.8f) }
    var ratioMode by remember(source) { mutableStateOf("Свободно") }
    var previewSize by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }
    val ratioOptions = listOf("Свободно", "Оригинал", "1:1", "4:3", "16:9")

    fun applyRatio(mode: String) {
        ratioMode = mode
        if (mode == "Свободно") return
        val target = when (mode) {
            "Оригинал" -> source.width.toFloat() / source.height.toFloat()
            "1:1" -> 1f
            "4:3" -> 4f / 3f
            else -> 16f / 9f
        }
        // Fractions are measured in source-image coordinates.
        var w = 0.82f
        var h = w * source.width / source.height / target
        if (h > 0.82f) { h = 0.82f; w = h * source.height / source.width * target }
        cropW = w.coerceIn(0.08f, 1f); cropH = h.coerceIn(0.08f, 1f)
        left = (1f - cropW) / 2f; top = (1f - cropH) / 2f
    }

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxWidth(0.98f).fillMaxHeight(0.96f), shape = RoundedCornerShape(8.dp), color = Color(0xFF111111)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onCancel) { Text("Отмена", color = Color.White) }
                    Text("Обрезка", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { left = 0f; top = 0f; cropW = 1f; cropH = 1f; ratioMode = "Свободно" }) { Text("Сбросить", color = Color.White) }
                }
                Text("Перетаскивайте рамку; тяните за угол, чтобы изменить её размер", color = Color.LightGray, fontSize = 12.sp)
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    val boxW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                    val boxH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
                    val imageScale = minOf(boxW / source.width, boxH / source.height)
                    val imageW = source.width * imageScale
                    val imageH = source.height * imageScale
                    val imageLeft = (boxW - imageW) / 2f
                    val imageTop = (boxH - imageH) / 2f
                    val currentLeft by rememberUpdatedState(left)
                    val currentTop by rememberUpdatedState(top)
                    val currentCropW by rememberUpdatedState(cropW)
                    val currentCropH by rememberUpdatedState(cropH)
                    val currentRatioMode by rememberUpdatedState(ratioMode)
                    androidx.compose.foundation.Canvas(Modifier.fillMaxSize().pointerInput(source, imageW, imageH) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            // Decide once on touch-down whether this gesture resizes a corner or moves the whole frame.
                            // Keeping this mode fixed for the entire gesture prevents the frame from stuttering.
                            val startLeft = currentLeft
                            val startTop = currentTop
                            val startW = currentCropW
                            val startH = currentCropH
                            val frameLeftPx = imageLeft + startLeft * imageW
                            val frameTopPx = imageTop + startTop * imageH
                            val frameRightPx = frameLeftPx + startW * imageW
                            val frameBottomPx = frameTopPx + startH * imageH
                            val handleRadius = 52f
                            val corners = listOf(
                                Triple("tl", frameLeftPx, frameTopPx), Triple("tr", frameRightPx, frameTopPx),
                                Triple("bl", frameLeftPx, frameBottomPx), Triple("br", frameRightPx, frameBottomPx)
                            )
                            val selectedCorner = corners.minByOrNull { (_, x, y) ->
                                val dx = down.position.x - x; val dy = down.position.y - y
                                dx * dx + dy * dy
                            }?.takeIf { (_, x, y) ->
                                val dx = down.position.x - x; val dy = down.position.y - y
                                dx * dx + dy * dy <= handleRadius * handleRadius
                            }?.first
                            val movingFrame = selectedCorner == null
                            var previous = down.position
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Main)
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                val drag = change.position - previous
                                previous = change.position
                                val dx = drag.x / imageW
                                val dy = drag.y / imageH
                                if (movingFrame) {
                                    // Translate by the full pointer delta; don't re-classify the gesture mid-drag.
                                    left = (currentLeft + dx).coerceIn(0f, 1f - currentCropW)
                                    top = (currentTop + dy).coerceIn(0f, 1f - currentCropH)
                                } else {
                                    val oldLeft = currentLeft; val oldTop = currentTop
                                    val oldW = currentCropW; val oldH = currentCropH
                                    val growLeft = selectedCorner == "tl" || selectedCorner == "bl"
                                    val growTop = selectedCorner == "tl" || selectedCorner == "tr"
                                    var newLeft = oldLeft; var newTop = oldTop
                                    var newW = oldW; var newH = oldH
                                    if (growLeft) { newLeft = (oldLeft + dx).coerceIn(0f, oldLeft + oldW - 0.12f); newW = oldW + oldLeft - newLeft }
                                    else { newW = (oldW + dx).coerceIn(0.12f, 1f - oldLeft); }
                                    if (growTop) { newTop = (oldTop + dy).coerceIn(0f, oldTop + oldH - 0.12f); newH = oldH + oldTop - newTop }
                                    else { newH = (oldH + dy).coerceIn(0.12f, 1f - oldTop); }
                                    if (currentRatioMode != "Свободно") {
                                        val target = when (currentRatioMode) {
                                            "Оригинал" -> source.width.toFloat() / source.height
                                            "1:1" -> 1f
                                            "4:3" -> 4f / 3f
                                            else -> 16f / 9f
                                        }
                                        val imageRatio = source.width.toFloat() / source.height
                                        val targetH = newW * imageRatio / target
                                        if (targetH <= 1f - newTop && targetH >= 0.12f) newH = targetH
                                        else newW = (newH * target / imageRatio).coerceIn(0.12f, 1f - newLeft)
                                        if (growLeft) newLeft = (oldLeft + oldW - newW).coerceIn(0f, 1f - newW)
                                        if (growTop) newTop = (oldTop + oldH - newH).coerceIn(0f, 1f - newH)
                                    }
                                    left = newLeft.coerceIn(0f, 1f - newW)
                                    top = newTop.coerceIn(0f, 1f - newH)
                                    cropW = newW.coerceIn(0.12f, 1f - left)
                                    cropH = newH.coerceIn(0.12f, 1f - top)
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }) {
                        val frame = androidx.compose.ui.geometry.Rect(imageLeft + left * imageW, imageTop + top * imageH, imageLeft + (left + cropW) * imageW, imageTop + (top + cropH) * imageH)
                        drawImage(source.asImageBitmap(), dstOffset = androidx.compose.ui.unit.IntOffset(imageLeft.toInt(), imageTop.toInt()), dstSize = androidx.compose.ui.unit.IntSize(imageW.toInt().coerceAtLeast(1), imageH.toInt().coerceAtLeast(1)))
                        drawRect(Color.Black.copy(alpha = 0.55f), androidx.compose.ui.geometry.Offset(imageLeft, imageTop), androidx.compose.ui.geometry.Size(imageW, imageH))
                        drawImage(source.asImageBitmap(), srcOffset = androidx.compose.ui.unit.IntOffset((left * source.width).toInt(), (top * source.height).toInt()), srcSize = androidx.compose.ui.unit.IntSize((cropW * source.width).toInt().coerceAtLeast(1), (cropH * source.height).toInt().coerceAtLeast(1)), dstOffset = androidx.compose.ui.unit.IntOffset(frame.left.toInt(), frame.top.toInt()), dstSize = androidx.compose.ui.unit.IntSize(frame.width.toInt().coerceAtLeast(1), frame.height.toInt().coerceAtLeast(1)))
                        drawRect(Color.White, frame.topLeft, androidx.compose.ui.geometry.Size(frame.width, frame.height), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))
                        for (i in 1..2) {
                            val x = frame.left + frame.width * i / 3f; val y = frame.top + frame.height * i / 3f
                            drawLine(Color.White.copy(alpha = 0.75f), androidx.compose.ui.geometry.Offset(x, frame.top), androidx.compose.ui.geometry.Offset(x, frame.bottom), 1.dp.toPx())
                            drawLine(Color.White.copy(alpha = 0.75f), androidx.compose.ui.geometry.Offset(frame.left, y), androidx.compose.ui.geometry.Offset(frame.right, y), 1.dp.toPx())
                        }
                        val handle = 9.dp.toPx()
                        listOf(frame.topLeft, androidx.compose.ui.geometry.Offset(frame.right, frame.top), androidx.compose.ui.geometry.Offset(frame.left, frame.bottom), frame.bottomRight).forEach { drawCircle(Color.White, handle, it) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ratioOptions.forEach { option ->
                        FilterChip(selected = ratioMode == option, onClick = { applyRatio(option) }, label = { Text(option, fontSize = 11.sp) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    val x = (source.width * left).toInt().coerceIn(0, source.width - 1)
                    val y = (source.height * top).toInt().coerceIn(0, source.height - 1)
                    val w = (source.width * cropW).toInt().coerceIn(1, source.width - x)
                    val h = (source.height * cropH).toInt().coerceIn(1, source.height - y)
                    onSave(Bitmap.createBitmap(source, x, y, w, h))
                }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить обрезанное фото") }
                Text("Оригинал останется без изменений", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun GalleryTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = GalleryBlue, secondary = Color(0xFF8956D9), background = PageBackground, surface = Color.White), content = content)
}

@Composable
private fun QuickTile(title: String, subtitle: String, bg: Color, fg: Color, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(bg), contentAlignment = Alignment.Center) { Icon(icon, null, tint = fg, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.height(7.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(subtitle, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
        }
    }
}

@Composable
private fun MediaThumbnail(item: MediaItem, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = ThumbnailCache.get(item.uri), key1 = item.uri) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                try { context.contentResolver.loadThumbnail(item.uri, Size(240, 240), null).also { ThumbnailCache.put(item.uri, it) } } catch (_: Exception) { null }
            }
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFE6E9EE))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = item.displayName, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(if (item.isVideo) Icons.Default.VideoLibrary else Icons.Default.ImageIcon, null, tint = Color(0xFF9AA2AE), modifier = Modifier.size(28.dp))
        if (item.isVideo) Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(24.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
            Text("▶", color = Color.White, fontSize = 10.sp)
        }
    }
}

private fun dateLabel(value: String): String {
    val today = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
    val yesterday = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000))
    return when (value) { today -> "Сегодня"; yesterday -> "Вчера"; else -> value }
}

private fun fileWord(count: Int): String = when {
    count % 10 == 1 && count % 100 != 11 -> "файл"
    count % 10 in 2..4 && count % 100 !in 12..14 -> "файла"
    else -> "файлов"
}
