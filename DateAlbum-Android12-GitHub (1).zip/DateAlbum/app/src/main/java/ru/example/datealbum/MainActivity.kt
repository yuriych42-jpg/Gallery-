package ru.example.datealbum

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class MediaItem(
    val uri: Uri,
    val dateKey: String,
    val displayName: String
)

class MainActivity : ComponentActivity() {
    private var pendingMove: List<MediaItem> = emptyList()
    private var pendingAlbumName: String = ""

    private val writePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) movePendingFiles()
        else Toast.makeText(this, "Перемещение отменено", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GalleryScreen() } }
    }

    private fun hasReadPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun queryMedia(): List<MediaItem> {
        val output = mutableListOf<MediaItem>()
        val collections = listOf(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        )
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.Images.ImageColumns.DATE_TAKEN
        )
        for (collection in collections) {
            contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val takenCol = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATE_TAKEN)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "media_$id"
                    val takenMillis = if (takenCol >= 0 && !cursor.isNull(takenCol)) cursor.getLong(takenCol) else 0L
                    val addedSeconds = cursor.getLong(addedCol)
                    val timestamp = if (takenMillis > 0L) takenMillis else addedSeconds * 1000L
                    val dateKey = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(timestamp))
                    output += MediaItem(ContentUris.withAppendedId(collection, id), dateKey, name)
                }
            }
        }
        return output.sortedByDescending { parseDate(it.dateKey) }
    }

    private fun parseDate(value: String): Long = try {
        SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).parse(value)?.time ?: 0L
    } catch (_: Exception) { 0L }

    @Composable
    private fun GalleryScreen() {
        var permissionGranted by remember { mutableStateOf(hasReadPermission()) }
        var media by remember { mutableStateOf(emptyList<MediaItem>()) }
        var selectedDate by remember { mutableStateOf<String?>(null) }
        var albumName by remember { mutableStateOf("") }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            permissionGranted = granted
            if (granted) media = queryMedia()
        }

        LaunchedEffect(permissionGranted) { if (permissionGranted) media = queryMedia() }

        if (!permissionGranted) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                Text("Разрешите доступ к фотографиям и видео, чтобы сгруппировать файлы по дате.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = { permissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE) }) {
                    Text("Разрешить доступ")
                }
            }
            return
        }

        val grouped = media.groupBy { it.dateKey }.toSortedMap(
            compareByDescending { parseDate(it) }
        )

        Scaffold(topBar = { CenterAlignedTopAppBarCompat("Альбомы по датам") }) { padding ->
            if (media.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("Медиафайлы не найдены.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    grouped.forEach { (date, dateItems) ->
                        item(key = date) {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(date, style = MaterialTheme.typography.titleMedium)
                                            Text("${dateItems.size} файлов")
                                        }
                                        Button(onClick = { selectedDate = date; albumName = date }) {
                                            Text("Создать альбом")
                                        }
                                    }
                                    dateItems.take(3).forEach { Text("• ${it.displayName}", style = MaterialTheme.typography.bodySmall) }
                                    if (dateItems.size > 3) Text("и ещё ${dateItems.size - 3}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        selectedDate?.let { date ->
            AlertDialog(
                onDismissRequest = { selectedDate = null },
                title = { Text("Название альбома") },
                text = {
                    Column {
                        Text("Будут перемещены все фото и видео группы $date.")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = albumName,
                            onValueChange = { albumName = it },
                            label = { Text("Имя альбома") },
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val safeName = albumName.trim().replace("/", "_").replace("\\", "_")
                        if (safeName.isBlank()) {
                            Toast.makeText(this, "Введите название альбома", Toast.LENGTH_SHORT).show()
                        } else {
                            pendingMove = media.filter { it.dateKey == date }
                            pendingAlbumName = safeName
                            selectedDate = null
                            requestMovePermission()
                        }
                    }) { Text("ОК") }
                },
                dismissButton = { TextButton(onClick = { selectedDate = null }) { Text("Отмена") } }
            )
        }
    }

    private fun requestMovePermission() {
        if (pendingMove.isEmpty()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val request = MediaStore.createWriteRequest(contentResolver, pendingMove.map { it.uri })
                writePermissionLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось запросить разрешение: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        } else movePendingFiles()
    }

    private fun movePendingFiles() {
        val targetPath = "DCIM/DateAlbums/${pendingAlbumName.trimEnd('/')}/"
        var moved = 0
        var failed = 0
        pendingMove.forEach { item ->
            try {
                val values = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath) }
                if (contentResolver.update(item.uri, values, null, null) > 0) moved++ else failed++
            } catch (_: Exception) { failed++ }
        }
        Toast.makeText(this, "Перемещено: $moved. Ошибок: $failed", Toast.LENGTH_LONG).show()
        pendingMove = emptyList()
        setContent { MaterialTheme { GalleryScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CenterAlignedTopAppBarCompat(title: String) {
    CenterAlignedTopAppBar(title = { Text(title) })
}
